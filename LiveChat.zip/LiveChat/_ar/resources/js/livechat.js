var liveChat = undefined;

function debug(msg) {
    console.log("[DEBUG] " + msg);
}

function initialize() {
    debug("In the initialize");
    $('#chat-customer-form').show();
    $('#waiting-time-dialog').hide();
    getCustomerInfo();
}

function replaceLabels(data) {
    $('#LBL_FIRST_NAME').text(data['messages']['LBL_FIRST_NAME']);
    $('#livechat-form-firstname').attr('placeholder', data['messages']['LBL_FIRST_NAME']);

    $('#LBL_LAST_NAME').text(data['messages']['LBL_LAST_NAME']);
    $('#livechat-form-lastname').attr('placeholder', data['messages']['LBL_LAST_NAME']);

    $('#LBL_EMAIL').text(data['messages']['LBL_EMAIL']);
    $('#livechat-form-email').attr('placeholder', data['messages']['LBL_EMAIL']);

    $('#LBL_MOBILE').text(data['messages']['LBL_MOBILE']);
    $('#livechat-form-mobile').attr('placeholder', data['messages']['LBL_MOBILE']);

    $('#LBL_SERVICE').text(data['messages']['LBL_SERVICE']);

    $('#proceed-to-chat-button').text(data['messages']['BTN_PROCCED_CHAT']);

    $('#cancel-chat-button').text(data['messages']['BTN_CANCEL_CHAT']);
    $('#wait-for-chat-button').text(data['messages']['BTN_WAIT_CHAT']);

    $('#MSG_SEC_HEADER').text(data['messages']['MSG_SEC_HEADER']);
    $('#MSG_MAIN_HEADER').text(data['messages']['MSG_MAIN_HEADER']);
    $('#MSG_SEC_HEADER').text(data['messages']['MSG_SEC_HEADER']);
    $('#LBL_WAITING_MINUTES').text(data['messages']['LBL_WAITING_MINUTES']);
}

function getLiveChatFn(data) {
    return ({
        isWorkingHours: true,
        validateChatCustomerForm: validateChatCustomerForm,
        buildServicesDropDown: buildServicesDropDown,
        clearMessageForm: clearMessageForm,
        isValidEmail: isValidEmail,
        isValidMobile: isValidMobile,
        proceedToChat: proceedToChat,
        waitForChat: waitForChat,
        cancelChatButton: cancelChatButton,
        activateChatWindow: activateChatWindow
    });

    function isValidEmail(email) {
        var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(email);
    }

    function isValidMobile(mobile) {
        var re = /^((00971)[0-9]{9}|(971)[0-9]{9}|(05)[0-9]{8}|(5)[0-9]{8})$/;
        return re.test(mobile);
    }

    function validateChatCustomerForm() {
        var isValid = true;
        var firstName = $('#livechat-form-firstname').val();
        if (!firstName) {
            $('#livechat-form-firstname-validation-message').css('display', '');
            setTimeout(function () {
                $('#livechat-form-firstname-validation-message').text(data['messages']
                ['LBL_FNAME_EMPTY']);
            }, 10);
            isValid = false;
        } else {
            $('#livechat-form-firstname-validation-message').css('display', 'none');
            isValid = isValid && true;
        }
        var lastName = $('#livechat-form-lastname').val();
        if (!lastName) {
            $('#livechat-form-lastname-validation-message').css('display', '');
            setTimeout(function () {
                $('#livechat-form-lastname-validation-message').text(data['messages']
                ['LBL_LNAME_EMPTY']);
            }, 10);
            isValid = false;
        } else {
            $('#livechat-form-lastname-validation-message').css('display', 'none');
            isValid = isValid && true;
        }
        var email = $('#livechat-form-email').val();
        if (!liveChat.isValidEmail(email)) {
            $('#livechat-form-email-validation-message').css('display', '');
            setTimeout(function () {
                $('#livechat-form-email-validation-message').text(data['messages']
                ['LBL_EMAIL_VALIDITY']);
            });
            isValid = false;
        } else {
            $('#livechat-form-email-validation-message').css('display', 'none');
            isValid = isValid && true;
        }

        var mobile = $('#livechat-form-mobile').val();
        if (!liveChat.isValidMobile(mobile)) {
            $('#livechat-form-mobile-validation-message').css('display', '');
            setTimeout(function () {
                $('#livechat-form-mobile-validation-message').text(data['messages']
                ['LBL_MOBILE_VALIDITY']);
            }, 10);
            isValid = false;
        } else {
            $('#livechat-form-mobile-validation-message').css('display', 'none');
            isValid = isValid && true;
        }

        return isValid;

    }

    function buildServicesDropDown() {
        var dropDown = '';
        var services = data['services'];
        if (services) {
            for (var i = 0; i < services.length; i += 1) {
                dropDown += '<option value="' + services[i].value + '">' +
                    services[i].name + "</option>";
            }
        }
        if (dropDown) {
            $('#livechat-form-service').html(dropDown);
        }
    }

    function clearMessageForm() {
        $('#livechat-form-firstname').val('');
        $('#livechat-form-firstname-validation-message').css('display', 'none');
        $('#livechat-form-lastname').val('');
        $('#livechat-form-lastname-validation-message').css('display', 'none');
        $('#livechat-form-email').val('');
        $('#livechat-form-email-validation-message').css('display', 'none');
        $('#livechat-form-message').val('');
        $('#livechat-form-message-validation-message').css('display', 'none');
        $('#livechat-form-mobile').val('');
        $('#livechat-form-mobile-validation-message').css('display', 'none');
    }

    // Option 1 First form - chat-customer-form
    function proceedToChat() {
        if (liveChat.validateChatCustomerForm()) {
            $('#chat-customer-form').hide();
            $('#waiting-time-dialog').show();
            let _fname = $('#livechat-form-firstname').val();
            let _lastName = $('#livechat-form-lastname').val();
            let _email = $('#livechat-form-email').val();
            let _mobile = $('#livechat-form-mobile').val();
            let _subject = $('#livechat-form-service').val();
            let customerInfo = {
                fname: _fname,
                lname: _lastName,
                email: _email,
                mobile: _mobile,
                subject: _subject
            };
            sessionStorage.setItem("customerInfo", JSON.stringify(customerInfo));
        }
    }

    // Option 1 Second Form - waiting-time-dialog
    function waitForChat() {
        $('#waiting-time-dialog').hide();
        $('#waiting-for-chat-dialog').show();
    }

    function activateChatWindow() {
        $('#waiting-for-chat-dialog').hide();
        window.location = "chatMain.html";
    }

    function cancelChatButton() {
        window.close();
        //alert("TODO");
        // TODO  CALL PARENT CLOSE
    }
}

function bindChatButtonEvents() {
    $('#proceed-to-chat-button').on('click', liveChat.proceedToChat);
    $('#wait-for-chat-button').on('click', liveChat.activateChatWindow);
    $('#cancel-chat-button').on('click', liveChat.cancelChatButton);
    liveChat.buildServicesDropDown();
}

$(document).ready(function () {
    $.ajax({
        url: 'resources/data/livechat.json',
        success: function (data) {
            if (typeof data === 'string') {
                data = JSON.parse(data);
            }
            liveChat = getLiveChatFn(data);
            bindChatButtonEvents();
            replaceLabels(data);
        },
        error: function (err) {
            console.log('Error occured while fetching livechat.json', err);
        }
    });

    initialize();
});

function getCustomerInfo() {
    var sessionData = sessionStorage.getItem('customerInfo');
    if (sessionData) {
        var custmerInfo = JSON.parse(sessionData);
        setCustomerInfo(custmerInfo);
    }
}

function setCustomerInfo(custmerInfo) {
    $('#livechat-form-firstname').val(custmerInfo.fname);
    $('#livechat-form-lastname').val(custmerInfo.lname);
    $('#livechat-form-email').val(custmerInfo.email);
    $('#livechat-form-mobile').val(custmerInfo.mobile);
    disableCustomerInfo(custmerInfo);
}

function disableCustomerInfo(custmerInfo) {
    if (custmerInfo.fname)
        $('#livechat-form-firstname').attr("disabled", "disabled");
    if (custmerInfo.lname)
        $('#livechat-form-lastname').attr("disabled", "disabled");
    if (custmerInfo.email)
        $('#livechat-form-email').attr("disabled", "disabled");
    if (custmerInfo.mobile)
        $('#livechat-form-mobile').attr("disabled", "disabled");
}

window.onbeforeunload = function (e) {
    if (window.opener.sessionStorage)
        window.opener.sessionStorage.removeItem('isChatWindowOpened');
};

