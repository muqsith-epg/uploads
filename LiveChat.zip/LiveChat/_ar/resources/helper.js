function GetWindowWidth()
{
    var myWidth = 0, myHeight = 0;
    if (typeof (window.innerWidth) == 'number')
    {
        //Non-IE
        myWidth = window.innerWidth;
        myHeight = window.innerHeight;
    }
    else if (document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight))
    {
        //IE 6+ in 'standards compliant mode'
        myWidth = document.documentElement.clientWidth;
        myHeight = document.documentElement.clientHeight;
    }
    else if (document.body && (document.body.clientWidth || document.body.clientHeight))
    {
        //IE 4 compatible
        myWidth = document.body.clientWidth;
        myHeight = document.body.clientHeight;
    }
    return myWidth;
}

function GetWindowHeight()
{
    var myWidth = 0, myHeight = 0;
    if (typeof (window.innerWidth) == 'number')
    {
        //Non-IE
        myWidth = window.innerWidth;
        myHeight = window.innerHeight;
    }
    else if (document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight))
    {
        //IE 6+ in 'standards compliant mode'
        myWidth = document.documentElement.clientWidth;
        myHeight = document.documentElement.clientHeight;
    }
    else if (document.body && (document.body.clientWidth || document.body.clientHeight))
    {
        //IE 4 compatible
        myWidth = document.body.clientWidth;
        myHeight = document.body.clientHeight;
    }
    return myHeight;
}

function getSelectedOption(opt)
{
    var c = null;
    var ret = null;
    for(c=0; c < opt.options.length; c++)
    {
        if(opt.options[c].selected)
        {
          ret = (opt.options[c].value == null || opt.options[c].value.length == 0) ? opt.options[c].text : opt.options[c].value;
          break;
        }
    }

    return ret;
}

function setSelection(objControl, Value)
{
    for( c=0; c < objControl.options.length; c++ )
    {
        if( objControl.options[c].value == Value )
        {
            objControl.options[c].selected = true;
            break;
        }
    }
}

function MouseOver(objTableRow)
{
    document.body.style.cursor = "pointer";
}

function MouseOut(objTableRow)
{
    document.body.style.cursor = "default";
}

function GetCaretPosition(ctrl)
{
    var CaretPos = 0;
    // IE Support
    if (document.selection)
    {

        ctrl.focus();
        var Sel = document.selection.createRange();
        var SelLength = document.selection.createRange().text.length;
        Sel.moveStart('character', -ctrl.value.length);
        CaretPos = Sel.text.length - SelLength;
    }
    // Firefox support
    else if (ctrl.selectionStart || ctrl.selectionStart == '0')
        CaretPos = ctrl.selectionStart;

    return (CaretPos);
}

function SetCaretPosition(obj, pos)
{
    if (obj.createTextRange)
    {
        var range = obj.createTextRange();
        range.move('character', pos);
        range.select();
    } else if (obj.selectionStart)
    {
        obj.focus();
        obj.setSelectionRange(pos, pos);
    }
}
