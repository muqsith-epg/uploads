var liveChat = undefined;

function debug(msg) {
    console.log("[DEBUG] " + msg);
}

function initialize() {
    debug("In the initialize");
    $('#non-working-hours-dialog').show();
    $('#chat-customer-form').hide();
    $('#get-back-next-working-hours-dialog').hide();
    getCustomerInfo();
}

function replaceLabels(data) {
    $('#LBL_FIRST_NAME').text(data['messages']['LBL_FIRST_NAME']);
    $('#livechat-form-firstname').attr('placeholder', data['messages']['LBL_FIRST_NAME']);

    $('#LBL_LAST_NAME').text(data['messages']['LBL_LAST_NAME']);
    $('#livechat-form-lastname').attr('placeholder', data['messages']['LBL_LAST_NAME']);

    $('#LBL_EMAIL').text(data['messages']['LBL_EMAIL']);
    $('#livechat-form-email').attr('placeholder', data['messages']['LBL_EMAIL']);

    $('#LBL_MOBILE').text(data['messages']['LBL_MOBILE']);
    $('#livechat-form-mobile').attr('placeholder', data['messages']['LBL_MOBILE']);

    $('#LBL_SERVICE').text(data['messages']['LBL_SERVICE']);
    $('#LBL_MESSAGE').text(data['messages']['LBL_MESSAGE']);

    $('#proceed-to-chat-button').text(data['messages']['BTN_PROCCED_CHAT']);

    $('#cancel-chat-button').text(data['messages']['BTN_CANCEL_CHAT']);
    $('#wait-for-chat-button').text(data['messages']['BTN_WAIT_CHAT']);

    $('#MSG_SEC_HEADER').text(data['messages']['MSG_SEC_HEADER']);
    $('#MSG_MAIN_HEADER').text(data['messages']['MSG_MAIN_HEADER']);
    $('#LBL_WAITING_MINUTES').text(data['messages']['LBL_WAITING_MINUTES']);

    $('#LBL_NON_WRK_HOURS_MSG').text(data['messages']['LBL_NON_WRK_HOURS_MSG']);
    $('#non-working-hours-dialog-yes-button').text(data['messages']['BTN_YES']);
    $('#non-working-hours-dialog-no-button').text(data['messages']['BTN_NO']);

}

function getLiveChatFn(data) {
    return ({
        isWorkingHours: false,
        validateChatCustomerForm: validateChatCustomerForm,
        buildServicesDropDown: buildServicesDropDown,
        clearMessageForm: clearMessageForm,
        isValidEmail: isValidEmail,
        isValidMobile: isValidMobile,
        nonWorkingHoursDialogYesButton: nonWorkingHoursDialogYesButton,
        nonWorkingHoursDialogNoButton: nonWorkingHoursDialogNoButton,
        chatCustomerFormSendMessageButton: chatCustomerFormSendMessageButton,
        getBackNextWorkingHoursDialogCloseButton: getBackNextWorkingHoursDialogCloseButton
    });

    function isValidEmail(email) {
        var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(email);
    }

    function isValidMobile(mobile) {
        var re = /^((00971)[0-9]{9}|(971)[0-9]{9}|(05)[0-9]{8}|(5)[0-9]{8})$/;
        return re.test(mobile);
    }

    function validateChatCustomerForm() {
        var isValid = true;
        var firstName = $('#livechat-form-firstname').val();
        if (!firstName) {
            $('#livechat-form-firstname-validation-message').css('display', '');
            setTimeout(function () {
                $('#livechat-form-firstname-validation-message').text(data['messages']
                ['LBL_FNAME_EMPTY']);
            }, 10);
            isValid = false;
        } else {
            $('#livechat-form-firstname-validation-message').css('display', 'none');
            isValid = isValid && true;
        }
        var lastName = $('#livechat-form-lastname').val();
        if (!lastName) {
            $('#livechat-form-lastname-validation-message').css('display', '');
            setTimeout(function () {
                $('#livechat-form-lastname-validation-message').text(data['messages']
                ['LBL_LNAME_EMPTY']);
            }, 10);
            isValid = false;
        } else {
            $('#livechat-form-lastname-validation-message').css('display', 'none');
            isValid = isValid && true;
        }
        var email = $('#livechat-form-email').val();
        if (!liveChat.isValidEmail(email)) {
            $('#livechat-form-email-validation-message').css('display', '');
            setTimeout(function () {
                $('#livechat-form-email-validation-message').text(data['messages']
                ['LBL_EMAIL_VALIDITY']);
            });
            isValid = false;
        } else {
            $('#livechat-form-email-validation-message').css('display', 'none');
            isValid = isValid && true;
        }

        var mobile = $('#livechat-form-mobile').val();
        if (!liveChat.isValidMobile(mobile)) {
            $('#livechat-form-mobile-validation-message').css('display', '');
            setTimeout(function () {
                $('#livechat-form-mobile-validation-message').text(data['messages']
                ['LBL_MOBILE_VALIDITY']);
            }, 10);
            isValid = false;
        } else {
            $('#livechat-form-mobile-validation-message').css('display', 'none');
            isValid = isValid && true;
        }

        if (!liveChat.isWorkingHours) {
            var message = $('#livechat-form-message').val();
            if (!message) {
                $('#livechat-form-message-validation-message').css('display', '');
                setTimeout(function () {
                    $('#livechat-form-message-validation-message').text(data['messages']
                    ['LBL_MSG_EMPTY']);
                }, 10);
                isValid = false;
            }
            //else if (message.length > data['messages']
            // ['non-working-hours']['form-validation-messages']
            // ['message-limit']) {
            //     $('#livechat-form-message-validation-message').css('display', '');
            //     setTimeout(function () {
            //         $('#livechat-form-message-validation-message').text(data['messages']
            //         ['non-working-hours']['form-validation-messages']
            //         ['excessive-message']);
            //     }, 10);
            //     isValid = false;
            // }
            else {
                $('#livechat-form-message-validation-message').css('display', 'none');
                isValid = isValid && true;
            }
        }

        return isValid;

    }

    function buildServicesDropDown() {
        var dropDown = '';
        dropDown += '<option value="' + data['messages']['LBL_SELECT_SERVICE'] + '">'
            + data['messages']['LBL_SELECT_SERVICE'] + '</option>"';
        dropDown += '<option value="' + data['messages']['LBL_DRPDW_EMS'] + '">'
            + data['messages']['LBL_DRPDW_EMS'] + '</option>"';
        dropDown += '<option value="' + data['messages']['LBL_DRPDW_POSTAL_SERVICES'] + '">'
            + data['messages']['LBL_DRPDW_POSTAL_SERVICES'] + '</option>"';
        dropDown += '<option value="' + data['messages']['LBL_DRPDW_COURIER_SERVICES'] + '">'
            + data['messages']['LBL_DRPDW_COURIER_SERVICES'] + '</option>"';
        dropDown += '<option value="' + data['messages']['LBL_DRPDW_COURIER_LICENSING'] + '">'
            + data['messages']['LBL_DRPDW_COURIER_LICENSING'] + '</option>"';
        dropDown += '<option value="' + data['messages']['LBL_DRPDW_OTHER_SERVICES'] + '">'
            + data['messages']['LBL_DRPDW_OTHER_SERVICES'] + '</option>"';
        if (dropDown) {
            $('#livechat-form-service').html(dropDown);
        }
    }

    function clearMessageForm() {
        $('#livechat-form-firstname').val('');
        $('#livechat-form-firstname-validation-message').css('display', 'none');
        $('#livechat-form-lastname').val('');
        $('#livechat-form-lastname-validation-message').css('display', 'none');
        $('#livechat-form-email').val('');
        $('#livechat-form-email-validation-message').css('display', 'none');
        $('#livechat-form-message').val('');
        $('#livechat-form-message-validation-message').css('display', 'none');
        $('#livechat-form-mobile').val('');
        $('#livechat-form-mobile-validation-message').css('display', 'none');
    }

    // Option 1 First form - nonWorkingHoursDialogYesButton
    function nonWorkingHoursDialogYesButton() {
        $('#non-working-hours-dialog').hide();
        $('#chat-customer-form').show();

    }

    // Option 1 First form - nonWorkingHoursDialogNoButton
    function nonWorkingHoursDialogNoButton() {
        window.close();
    }

    // Option 2 Second Form - chatCustomerFormSendMessageButton,
    function chatCustomerFormSendMessageButton() {
        var baseUrl = 'http://intranet/';
        var relativeUrl = 'api_mobile/app/send-email';
        var path = baseUrl + relativeUrl;
        var _data = {};
        _data.sender = 'EPGChat';
        _data.name = $('#livechat-form-firstname').val() + ' ' + $('#livechat-form-lastname').val();
        //semicolon seperated for multiple emails;
        _data.recepientList = 'myousif@epg.gov.ae'; //$('#livechat-form-email').val(); // 'malakkaran.pappachan@epg.gov.ae';
        _data.subject = 'Service - ' + $('#livechat-form-service').find(":selected").text();
        _data.body = $('#livechat-form-message').val();
        _data.subject = encodeHTML(_data.subject);
        _data.body = encodeHTML(_data.body);
        _data.name = encodeHTML(_data.name);
        localStorage.setItem("customerInfo", JSON.stringify(_data));
        if (liveChat.validateChatCustomerForm()) {
            $.ajax({
                url: path,
                method: 'POST',
                contentType: 'application/x-www-form-urlencoded; charset=UTF-8',
                data: _data,
                success: function (data) {
                    console.log(data);
                },
                error: function (request, status, err) {
                    console.log(request, status, err);
                }
            });
            $('#chat-customer-form').hide();
            $('#get-back-next-working-hours-dialog').show();
        }
    }

    function encodeHTML(s) {
        return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;');
    }

    function getBackNextWorkingHoursDialogCloseButton() {
        window.close();
    }

}

function bindChatButtonEvents() {
    $('#non-working-hours-dialog-yes-button').on('click', liveChat.nonWorkingHoursDialogYesButton);
    $('#non-working-hours-dialog-no-button').on('click', liveChat.nonWorkingHoursDialogNoButton);
    $('#chat-customer-form-send-message-button').on('click', liveChat.chatCustomerFormSendMessageButton);
    $('#get-back-next-working-hours-dialog-close-button').on('click', liveChat.getBackNextWorkingHoursDialogCloseButton);
    liveChat.buildServicesDropDown();
}


$(document).ready(function () {
    $.ajax({
        url: 'resources/data/offlineLiveChat.json',
        success: function (data) {
            if (typeof data === 'string') {
                data = JSON.parse(data);
            }
            liveChat = getLiveChatFn(data);
            bindChatButtonEvents();
            replaceLabels(data);
        },
        error: function (err) {
            console.log('Error occured while fetching livechat.json', err);
        }
    });

    initialize();
});

function getCustomerInfo() {
    var sessionData = sessionStorage.getItem('customerInfo');
    if (sessionData) {
        var custmerInfo = JSON.parse(sessionData);
        setCustomerInfo(custmerInfo);
    }

}

function setCustomerInfo(custmerInfo) {
    $('#livechat-form-firstname').val(custmerInfo.fname);
    $('#livechat-form-lastname').val(custmerInfo.lname);
    $('#livechat-form-email').val(custmerInfo.email);
    $('#livechat-form-mobile').val(custmerInfo.mobile);
    disableCustomerInfo(custmerInfo);
}

function disableCustomerInfo(custmerInfo) {
    if (custmerInfo.fname)
        $('#livechat-form-firstname').attr("disabled", "disabled");
    if (custmerInfo.lname)
        $('#livechat-form-lastname').attr("disabled", "disabled");
    if (custmerInfo.email)
        $('#livechat-form-email').attr("disabled", "disabled");
    if (custmerInfo.mobile)
        $('#livechat-form-mobile').attr("disabled", "disabled");
}


function getCustomerMappedModel(model) {
    return {
        fnameArabic: checkEmpty(model.customerName.arabic.first),
        fnameEnglish: checkEmpty(model.customerName.english.first),
        lnameArabic: checkEmpty(model.customerName.arabic.last),
        lnameEnglish: checkEmpty(model.customerName.english.last),
        mobile: model.addressProfile.contact ? checkEmpty(model.addressProfile.contact.mobile) : null,
        email: model.addressProfile.contact ? checkEmpty(model.addressProfile.contact.email) : null
    };
}

function checkEmpty() {
    if (val == '-' || val == ' ' || val == '' || val == null || val == undefined || val == [] || val == {}) {
        return '';
    } else {
        return val;
    }
}

window.onbeforeunload = function (e) {
    window.opener.sessionStorage.removeItem('isChatWindowOpened');
};