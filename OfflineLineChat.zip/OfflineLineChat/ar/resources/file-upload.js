function initFileUpload()
{
	var fakeFileUpload = document.createElement("div");
	fakeFileUpload.className = "samplesFakeFile";

	var objFakeFileInput = document.createElement("input");
	objFakeFileInput.className = "samplesFakeFileInput samplesFakeFileInputMargin";
	fakeFileUpload.appendChild(objFakeFileInput);

	var image = document.createElement("img");
	image.src = "../Resources/Images/button_select.gif";
	fakeFileUpload.appendChild(image);
	var x = document.getElementsByTagName("input");
	for (var i = 0; i < x.length; i++)
	{
	    if (x[i].type != "file")
		    continue;
		if (x[i].getAttribute("noscript"))
		    continue;
		if (x[i].parentNode.className != "samplesCoolFileInputs")
		    continue;
		x[i].className = "examplesCoolFile examplesCoolFileHidden";
		var clone = fakeFileUpload.cloneNode(true);
		x[i].parentNode.appendChild(clone);
		x[i].relatedElement = clone.getElementsByTagName("input")[0];
		if (x[i].value)
			x[i].onchange();
        x[i].onchange = x[i].onmouseout = function()
		{
			this.relatedElement.value = this.value;
		}
	}
}
